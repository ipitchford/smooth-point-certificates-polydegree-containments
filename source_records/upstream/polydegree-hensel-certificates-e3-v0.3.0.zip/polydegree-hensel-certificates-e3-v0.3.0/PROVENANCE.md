# Provenance

1. Project A version 0.2.0 combined a curve-theoretic methods note with a separate finite-field Polydegree extension.
2. A full review dated 7 August 2026 recommended splitting the papers, reframing the endpoint, deriving the source encoding explicitly, shipping controls and adding a separate full-range computer-algebra implementation.
3. Version 0.3.0 implements those revisions.
4. The frozen witness data are unchanged from version 0.2.0. Claims, proofs, reports, verifier labels and release architecture are revised.
5. The separate Wolfram Language program was written from Lewis-Perry-Straub's weighted sums. Its first run exposed and then corrected a `0^0` representation issue on zero-coordinate witnesses.
6. No public repository, tag or DOI has yet been assigned.
