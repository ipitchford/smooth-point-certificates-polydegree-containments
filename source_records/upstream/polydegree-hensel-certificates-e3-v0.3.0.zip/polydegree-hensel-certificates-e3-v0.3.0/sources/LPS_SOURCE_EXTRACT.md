# Pinned source extract: Lewis-Perry-Straub

**Source:** Drew Lewis, Kaitlyn Perry and Armin Straub, *An algorithmic approach to the Polydegree Conjecture for plane polynomial automorphisms*.  
**Pinned version:** arXiv:1809.09681v1, identifier dated 25 September 2018; 13-page preprint; journal DOI 10.1016/j.jpaa.2019.04.002.  
**Retrieval record:** arXiv PDF parsed and inspected on 7 August 2026.  
**Load-bearing locations:** preprint pages 2-3: definitions of \(g_{d,e}\), \(\alpha_{i,j,e}\), \(a_{d,e}\), and Theorem 4.

This file is a short mathematical transcription for auditability, not a substitute copy of the source PDF.

For \(\mathbf a=(a_1,\ldots,a_e)\), put

\[
|\mathbf a|=a_1+\cdots+a_e,
\qquad
\mathbf a\cdot\mathbb N=a_1+2a_2+\cdots+ea_e.
\]

The source defines

\[
g_{d,e}=\frac{1}{d+1}
\sum_{\mathbf a\cdot\mathbb N=d}
(-1)^{|\mathbf a|}
\binom{d+|\mathbf a|}{a_1,\ldots,a_e,d}
 x_1^{a_1}\cdots x_e^{a_e},
\]

\[
\alpha_{i,j,e}=
\sum_{\mathbf a\cdot\mathbb N=j-i}
(-1)^{|\mathbf a|}
\binom{|\mathbf a|+j+2}{a_1,\ldots,a_e,j+2}
 x_1^{a_1}\cdots x_e^{a_e},
\]

and

\[
a_{d,e}=\det\bigl(\alpha_{i,j,e}\bigr)_{
0\le i\le e-1,\ d-1\le j\le d+e-2}.
\]

Theorem 4 states that, for \(d\ge2\) and \(e\ge1\), a complex specialisation satisfying

\[
g_{d+i,e}=0\quad(0\le i\le e-2),
\qquad
g_{d+e-1,e}\ne0,
\qquad a_{d,e}\ne0
\]

implies

\[
\mathcal G_{(d+e)}\subseteq\overline{\mathcal G_{(d,e+1)}}.
\]

For \(e=3\), the package therefore checks exactly

\[
g_{d,3}=g_{d+1,3}=0,
\qquad g_{d+2,3}\ne0,
\qquad a_{d,3}\ne0.
\]

**Authoritative source URL:** https://arxiv.org/pdf/1809.09681v1  
**Journal DOI:** https://doi.org/10.1016/j.jpaa.2019.04.002
