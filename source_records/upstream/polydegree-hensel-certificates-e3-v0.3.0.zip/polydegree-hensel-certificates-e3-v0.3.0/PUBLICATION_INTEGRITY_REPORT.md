# Publication-integrity report

- The title states `51 additional cases`, not a natural threshold at 100.
- The abstract separates internal Python replay, separate Wolfram implementation and unaffiliated reproduction.
- The inherited \(d<50\) range is never labelled as replayed by this package.
- The manuscript derives every index from the pinned source definitions.
- The Hensel proof explicitly uses a unital map, a non-zero finite-type algebra, faithful flatness and the weak Nullstellensatz.
- Mutation controls verify that acceptance logic is live.
- The Wolfram report records the initial `0^0` issue and corrected full pass.
- No personal data, confidential inputs or third-party figures are included.
- Git/tag/DOI identity and public-download byte checks remain pending publication.

## Final local source and PDF checks

- The exact Lewis-Perry-Straub source version and load-bearing locations are recorded. A local mathematical transcription is hashed; the remote PDF-byte hash remains a public-archive task and is not fabricated.
- `MANUSCRIPT.pdf`: 8 pages; openable; unencrypted; text-based; no XFA; no replacement glyphs found in text extraction.
- Rendered at 200 dpi and visually inspected; no clipping, overlap, black boxes or broken glyphs were found.
