# Release notes

## Version 0.3.0 - 7 August 2026

- Split from the geometric divisor paper.
- Reframed \(d=100\) as a frozen release boundary.
- Added numbered Lagrange-inversion, alpha-coefficient and derivative lemmas.
- Added an explicit source index map and hand traces at \(d=50,75,100\).
- Renamed internal implementation diversity correctly.
- Added a full-range Wolfram Language implementation: 51/51.
- Added four mutation controls.
- Added prime-frequency and search-cost summaries.
- Added provenance, sources, status, privacy, integrity, RO-Crate, environment and manifest records.
- Added a hashed local transcription of the load-bearing source definitions and disclosed that the remote PDF-byte hash remains pending.
- Passed PDF preflight and 200 dpi visual inspection.
