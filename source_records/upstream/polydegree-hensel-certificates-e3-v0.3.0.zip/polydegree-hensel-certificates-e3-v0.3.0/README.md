# Smooth finite-field certificates for 51 additional e=3 Polydegree cases

**Version:** 0.3.0  
**Date:** 7 August 2026  
**Status:** candidate computer-assisted mathematics note; local Python and separate-CAS replays passed; not independently reproduced or peer reviewed  
**Author:** Anonymous

This package contains the finite-field/Hensel half of the split Project A candidate. It records one smooth modular certificate for each \(50\le d\le100\), derives every encoded polynomial and index from Lewis-Perry-Straub's published definitions, and supplies three verification layers.

## Evidence layers

1. Two internal algebraically distinct Python implementations: 51/51.
2. A separate full-range Wolfram Language implementation written from the published sums: 51/51.
3. Four shipped mutation controls: 4/4 rejected.

The endpoint \(100\) is a frozen release boundary, not a mathematical threshold. The published lower range \(d<50\) is external and is not replayed here.

## Replay

```bash
./repro/run_all.sh
```

The Python replay uses only the standard library. The Wolfram script is executed separately because it requires a licensed Wolfram Language kernel.

The Wolfram script is `repro/wolfram_full_range_reimplementation.wl`; its frozen report records 51/51. The pinned source transcription and its SHA-256 are in `sources/LPS_SOURCE_EXTRACT.md` and `SOURCES.md`.

## Contents

- `MANUSCRIPT.pdf`, `MANUSCRIPT.md`, `MANUSCRIPT.tex`.
- `ENCODING_AUDIT.md`: compact source-to-code bridge.
- `CERTIFICATE_TABLE.md` and machine-readable JSON/CSV.
- Python verifier, deterministic search, Wolfram reimplementation and mutation tests.
- Assurance, status, claim ledger, provenance, sources, integrity/privacy reports, RO-Crate metadata and manifest.
