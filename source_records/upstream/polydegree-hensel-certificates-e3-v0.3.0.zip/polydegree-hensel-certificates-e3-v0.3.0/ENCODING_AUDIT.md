# Encoding audit

## Source pin

Lewis, Perry and Straub, arXiv:1809.09681v1, pages 2-3, definitions of \(g_{d,e}\), \(\alpha_{i,j,e}\), \(a_{d,e}\), and Theorem 4. A local mathematical transcription is frozen at `sources/LPS_SOURCE_EXTRACT.md` with SHA-256 `99df7fe81d1ea0c7cd0fa39f16df3f715b9474e0e38bcff2d83bb446bcb80917`; this hash is not represented as the remote PDF hash.

## Exact bridge

With \(x_1=1\), \(\Phi(z)=1+z+uz^2+vz^3\), \(F(z)=z\Phi(z)\), and \(I=F^{-1}\):

\[
G_d=[w^{d+1}]I=\frac1{d+1}[z^d]\Phi^{-(d+1)},
\]

\[
\alpha_{i,j,3}(1,u,v)=[z^{j-i}]\Phi^{-(j+3)},
\]

\[
\partial_uG_d=-[z^{d-2}]\Phi^{-(d+2)},
\qquad
\partial_vG_d=-[z^{d-3}]\Phi^{-(d+2)}.
\]

The determinant uses rows \(i=0,1,2\) and columns \(j=d-1,d,d+1\). The Hensel Jacobian uses \(G_d,G_{d+1}\) against \(u=x_2,v=x_3\). The required non-zero next term is \(G_{d+2}\).

## Implementation map

| Published object | Direct Python | Series Python | Wolfram Language |
|---|---|---|---|
| \(G_d\) | weighted multinomial sum | coefficient of inverse series | weighted multinomial sum |
| derivatives | differentiated monomials | dual-number inverse series | differentiated monomials |
| \(A_d\) | alpha weighted sums | inverse powers of \(\Phi\) | alpha weighted sums |
| \(J_d\) | determinant of direct derivatives | determinant of dual derivatives | determinant of direct derivatives |

No generated coefficient table is shared with the Wolfram route.
