# Prior-art audit

**Audit date:** 7 August 2026.

Lewis, Perry and Straub report the \(e=3,d<50\) and \(e=4,d<20\) computational ranges. A dated public search across arXiv, publisher metadata, author publication lists and broad scholarly search did not locate a later continuous \(e=3\) extension or the specific \(d=50\) certificate. This is provisional negative evidence only.

The Hensel theorem uses standard lifting and commutative algebra. Candidate novelty lies in the compact smooth-modular certificate design for this criterion and the 51 frozen cases.

Safe wording:

> The package supplies candidate certificates for 51 additional cases beyond the range reported in the pinned Lewis-Perry-Straub source. No later extension was located in the inspected public corpus.

Unsupported wording:

> These cases have never been proved or computed before.
