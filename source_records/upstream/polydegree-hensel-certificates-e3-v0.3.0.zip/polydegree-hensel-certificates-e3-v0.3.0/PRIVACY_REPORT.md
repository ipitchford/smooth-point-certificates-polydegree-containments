# Privacy report

No personal data, private correspondence, credentials, unpublished third-party files or confidential datasets are included. The author is listed as `Anonymous`. Publicly named researchers appear only in bibliographic citations.
