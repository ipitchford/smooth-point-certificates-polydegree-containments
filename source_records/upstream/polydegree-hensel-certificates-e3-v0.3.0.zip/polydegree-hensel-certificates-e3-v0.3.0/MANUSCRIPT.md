---
title: "Smooth Finite-Field Certificates for 51 Additional e=3 Polydegree Cases"
subtitle: "A frozen d=50:100 computational note with a full encoding audit"
author: "Anonymous"
date: "7 August 2026"
version: "0.3.0"
status: "Candidate computer-assisted mathematics note; not peer reviewed"
toc: true
toc-depth: 2
numbersections: true
geometry: margin=30mm
mainfont: "Linux Libertine O"
mathfont: "DejaVu Math TeX Gyre"
colorlinks: true
linkcolor: "MidnightBlue"
urlcolor: "MidnightBlue"
header-includes:
  - \usepackage{booktabs}
  - \usepackage{longtable}
  - \usepackage{microtype}
  - \usepackage{xcolor}
  - \definecolor{MidnightBlue}{RGB}{25,55,95}
---

# Abstract

Lewis, Perry and Straub defined integral polynomials \(g_{d,e}\) and \(a_{d,e}\) whose complex specialisations certify Polydegree containments. For \(e=3\), their paper reports computer verification for \(d<50\). This note supplies 51 additional finite-field certificates, one for each \(50\le d\le100\). At a recorded point \((1,u,v)\in\mathbf F_p^3\), the two equations \(g_{d,3}=g_{d+1,3}=0\) hold, the \((x_2,x_3)\)-Jacobian determinant is non-zero, and \(g_{d+2,3}a_{d,3}\ne0\). Multivariate Hensel lifting, localisation, faithful base change and the weak Nullstellensatz then produce the complex specialisation required by Lewis-Perry-Straub Theorem 4.

The note derives every encoded object from the published definitions. It proves the inverse-series identities used by one replay path, writes the derivative and determinant indices explicitly, and gives hand-auditable traces at \(d=50,75,100\). All 51 rows pass two algebraically distinct Python implementations and a separate full-range Wolfram Language reimplementation written directly from the published sums. Shipped mutation controls reject corrupted residues, points, range completeness and an index shift.

The endpoint \(d=100\) is a frozen project boundary, not a mathematical threshold. The result is a finite candidate extension, not an all-\(d\) theorem or a proof of the Polydegree Conjecture. No unaffiliated group or specialist has yet reproduced or reviewed it.

# Scope and status

This paper is logically independent of the companion divisor-theory note. It uses smooth modular points and commutative algebra, not Weierstrass gaps.

| Layer | Status |
|---|---|
| Encoding lemmas and Hensel-specialisation theorem | Proved in this manuscript using cited standard results. |
| 51 finite-field certificates | Exactly replayed by two internal Python implementations. |
| Separate computer-algebra implementation | Full range replayed in Wolfram Language 15.0.1 from the published definitions, without importing Python formulas or coefficient tables. |
| Lewis-Perry-Straub Theorem 4 | Externally inherited. |
| Lewis-Perry-Straub range \(d<50\) | Externally reported and not replayed here. |
| Priority | Public search only; provisional. |
| Independent group reproduction, specialist review, peer review | Not assessed. |

The phrase **51 additional cases** means precisely the frozen interval \(50\le d\le100\). The value \(100\) has no claimed mathematical significance. An exploratory reuse of the discovery script found witnesses for \(101\le d\le120\), but those rows are excluded because they were not part of the frozen, fully audited corpus.

# Published definitions and the encoding bridge

We pin the source to Lewis, Perry and Straub, arXiv:1809.09681v1, submitted 25 September 2018, especially pages 2-3 and Theorem 4. For \(\mathbf a=(a_1,a_2,a_3)\), put

\[
|\mathbf a|=a_1+a_2+a_3,
\qquad
\mathbf a\cdot\mathbf N=a_1+2a_2+3a_3.
\]

Their polynomials are

\[
g_{d,3}(x_1,x_2,x_3)
=\frac1{d+1}
\sum_{\mathbf a\cdot\mathbf N=d}
(-1)^{|\mathbf a|}
\frac{(d+|\mathbf a|)!}{d!a_1!a_2!a_3!}
 x_1^{a_1}x_2^{a_2}x_3^{a_3},
\]

\[
\alpha_{i,j,3}
=\sum_{\mathbf a\cdot\mathbf N=j-i}
(-1)^{|\mathbf a|}
\frac{(j+2+|\mathbf a|)!}{(j+2)!a_1!a_2!a_3!}
 x_1^{a_1}x_2^{a_2}x_3^{a_3},
\]

and

\[
a_{d,3}=\det(\alpha_{i,j,3})_{\substack{0\le i\le2\\d-1\le j\le d+1}}.
\]

Work in the affine chart \(x_1=1\). Define

\[
G_d(u,v)=g_{d,3}(1,u,v),
\qquad
A_d(u,v)=a_{d,3}(1,u,v),
\]

and

\[
\Phi(z)=1+z+uz^2+vz^3,
\qquad
F(z)=z\Phi(z)=z+z^2+uz^3+vz^4.
\]

## Lemma 2.1. Inverse-series identity and integrality

Let \(I(w)\in w\mathbf Z[u,v][[w]]\) be the unique compositional inverse of \(F\). Then

\[
G_d(u,v)=[w^{d+1}]I(w).
\]

In particular, \(G_d\in\mathbf Z[u,v]\).

### Proof

The Lagrange inversion formula gives

\[
[w^{d+1}]I(w)
=\frac1{d+1}[z^d]\Phi(z)^{-(d+1)}.
\]

Expanding the negative power multinomially, the coefficient of \(z^d\) is the sum over \(a_1+2a_2+3a_3=d\) displayed in the definition of \(g_{d,3}(1,u,v)\). The recursive identity \(F(I(w))=w\) determines every coefficient of \(I\) by integer polynomial operations from earlier coefficients, proving integrality. \(\square\)

## Lemma 2.2. Alpha-matrix coefficient identity

For every \(i,j\),

\[
\alpha_{i,j,3}(1,u,v)
=[z^{j-i}]\Phi(z)^{-(j+3)},
\]

where the coefficient is \(0\) when \(j-i<0\).

### Proof

The multinomial expansion of \(\Phi^{-(j+3)}\) has coefficient

\[
(-1)^{|\mathbf a|}
\frac{(j+2+|\mathbf a|)!}{(j+2)!a_1!a_2!a_3!}
\]

at \(z^{a_1+2a_2+3a_3}u^{a_2}v^{a_3}\), exactly as required. \(\square\)

## Lemma 2.3. Derivative and Jacobian identities

Differentiating the coefficient formula gives

\[
\frac{\partial G_d}{\partial u}
=-[z^{d-2}]\Phi(z)^{-(d+2)},
\qquad
\frac{\partial G_d}{\partial v}
=-[z^{d-3}]\Phi(z)^{-(d+2)}.
\]

The Jacobian used in every certificate is

\[
J_d(u,v)=
\det
\begin{pmatrix}
\partial_uG_d&\partial_vG_d\\
\partial_uG_{d+1}&\partial_vG_{d+1}
\end{pmatrix}.
\]

The complete index map is therefore:

| Object | Encoded quantity |
|---|---|
| First equation | \(G_d=[w^{d+1}]I\) |
| Second equation | \(G_{d+1}=[w^{d+2}]I\) |
| Required non-zero next term | \(G_{d+2}=[w^{d+3}]I\) |
| Determinant | rows \(i=0,1,2\), columns \(j=d-1,d,d+1\) |
| Smoothness minor | variables \((u,v)=(x_2,x_3)\) for equations \((G_d,G_{d+1})\) |

These lemmas close the main encoding risk: the direct multinomial path and the inverse-series path now meet at numbered identities derived from the source definitions.

# Hensel-specialisation theorem

## Theorem 3.1

Let \(d\ge2\), let \(p\) be prime, and suppose \((\bar u,\bar v)\in\mathbf F_p^2\) satisfies

\[
G_d(\bar u,\bar v)=G_{d+1}(\bar u,\bar v)=0
\]

and

\[
G_{d+2}(\bar u,\bar v)A_d(\bar u,\bar v)J_d(\bar u,\bar v)\ne0.
\]

Then there is \((U,V)\in\mathbf C^2\) such that

\[
G_d(U,V)=G_{d+1}(U,V)=0,
\qquad
G_{d+2}(U,V)A_d(U,V)\ne0.
\]

Consequently, Lewis-Perry-Straub Theorem 4 gives

\[
\mathcal G_{(d+3)}
\subseteq
\overline{\mathcal G_{(d,4)}}.
\]

### Proof

The non-zero determinant \(J_d(\bar u,\bar v)\) makes the modular solution simple. Multivariate Hensel lifting gives a unique lift \((u_p,v_p)\in\mathbf Z_p^2\) in the same residue class satisfying \(G_d=G_{d+1}=0\). The values of \(G_{d+2}\) and \(A_d\) remain \(p\)-adic units.

Consider the localisation

\[
R_d=
\mathbf Q[u,v,1/(G_{d+2}A_d)]/(G_d,G_{d+1}).
\]

Evaluation at \((u_p,v_p)\) defines a **unital** homomorphism \(R_d\to\mathbf Q_p\), because the inverted element maps to a unit. Therefore \(R_d\ne0\). Every field extension is faithfully flat, so

\[
R_d\otimes_{\mathbf Q}\mathbf C\ne0.
\]

This is a non-zero finitely generated \(\mathbf C\)-algebra. It has a maximal ideal, and the weak Nullstellensatz identifies the residue field with \(\mathbf C\). The associated complex point satisfies the two equations and avoids the inverted factors. Lewis-Perry-Straub Theorem 4 supplies the containment. \(\square\)

The argument does not assert an embedding \(\mathbf Q_p\hookrightarrow\mathbf C\).

# Frozen witness corpus

The data file stores one tuple

\[
(d,p,(1,u,v),G_{d+2},A_d,J_d)
\]

for each \(50\le d\le100\). All residues are represented in \(\{0,\ldots,p-1\}\). The deterministic discovery scan tests primes

\[
5,7,11,13,17,19,23,29,31,37
\]

and then affine points in lexicographic order. Version 0.3.0 freezes the first qualifying point under that order.

## Hand trace: d=50

At \(p=5\), \((1,u,v)=(1,3,1)\),

\[
(G_{50},G_{51},G_{52})=(0,0,4).
\]

The alpha and Jacobian matrices are

\[
\begin{pmatrix}2&0&1\\4&4&1\\3&2&0\end{pmatrix},
\qquad
\begin{pmatrix}1&2\\1&3\end{pmatrix},
\]

with determinants \(A_{50}=2\) and \(J_{50}=1\).

## Hand trace: d=75

At \(p=17\), \((1,u,v)=(1,6,6)\),

\[
(G_{75},G_{76},G_{77})=(0,0,5).
\]

The matrices are

\[
\begin{pmatrix}5&8&3\\10&5&16\\11&0&15\end{pmatrix},
\qquad
\begin{pmatrix}7&6\\12&0\end{pmatrix},
\]

with determinants \(A_{75}=10\) and \(J_{75}=13\).

## Hand trace: d=100

At \(p=19\), \((1,u,v)=(1,0,6)\),

\[
(G_{100},G_{101},G_{102})=(0,0,14).
\]

The matrices are

\[
\begin{pmatrix}1&15&18\\18&12&16\\1&15&2\end{pmatrix},
\qquad
\begin{pmatrix}1&18\\7&4\end{pmatrix},
\]

with determinants \(A_{100}=5\) and \(J_{100}=11\).

## Corpus summary

| Prime p | Number of frozen witnesses |
| --- | --- |
| 5 | 9 |
| 7 | 9 |
| 11 | 8 |
| 13 | 9 |
| 17 | 4 |
| 19 | 6 |
| 23 | 4 |
| 37 | 2 |

The discovery replay for the 51 rows took approximately 14.1 seconds in the original frozen run. Runtime is not part of the certificate and varies by platform.

# Verification and controls

## Internal Python replay

Implementation A evaluates the published multinomial sums, derivatives and \(3\times3\) determinants directly. Implementation B uses Lemmas 2.1-2.3: compositional inversion, dual-number differentiation and inverse powers of \(\Phi\). Both are contained in one Python file and were developed within the same project. They are **internal algebraically distinct implementations**, not independent external reproduction.

Result:

```text
Internal algebraically distinct Python implementations: 2
Witnesses passed: 51/51
Overall status: PASS
```

## Separate Wolfram Language implementation

A separate Wolfram Language 15.0.1 program evaluates the defining weighted sums and derivatives directly. It imports the frozen witness tuples but no Python code, generated coefficient tables or intermediate formulas. The full range passes 51/51.

The first literal implementation exposed a language-specific issue: Mathematica treats \(0^0\) as indeterminate, whereas a monomial with exponent zero has value \(1\). Nine zero-coordinate rows failed. An explicit non-negative integer power function repaired that representation issue, after which all rows passed. This debugging trace is recorded because it shows the separate route was live rather than a copied report.

## Mutation and negative controls

The shipped suite checks that the verifier rejects:

1. a corrupted stored value of \(G_{d+2}\);
2. a corrupted finite-field point;
3. a missing \(d=100\) row; and
4. a deliberate one-step index shift in the first equation.

All four controls are rejected.

# Candidate result and exact boundary

Applying Theorem 3.1 to every frozen row gives the candidate finite result

\[
\boxed{
\mathcal G_{(d+3)}
\subseteq
\overline{\mathcal G_{(d,4)}}
\quad\text{for }50\le d\le100.
}
\]

Lewis, Perry and Straub reported the same form of containment for \(e=3,d<50\). Their lower range is an externally inherited result and was not replayed by this package. Combining their report with the present candidate certificates would give the continuous interval \(2\le d\le100\), but the two evidence layers must remain distinct.

The package does not prove:

- an infinite family or all-\(d\) result;
- the Polydegree Ideal Conjecture;
- the full Polydegree Conjecture;
- priority over unpublished or unindexed computations;
- specialist acceptance or independent group reproduction.

# Research programme

The next result should explain the witness sequence rather than extend another arbitrary prefix. High-value targets are:

1. a periodic or automatic construction by congruence class of \(d\);
2. a proof that a bounded set of primes suffices for infinitely many or all \(d\);
3. a density theorem for smooth modular witnesses;
4. an extension to \(e=4\), where three equations require a full-rank \(3\times3\) Jacobian minor;
5. a specialist audit of the source-definition bridge and a wholly unaffiliated replay.

# Sanity checks

1. Every certificate has three non-zero exclusion residues: \(G_{d+2}\), \(A_d\) and \(J_d\).
2. The Lagrange-inversion index is \(d+1\); the next two equations use \(d+2\) and \(d+3\).
3. The alpha determinant uses rows \(0,1,2\) and columns \(d-1,d,d+1\), exactly as in the source.
4. The proof passes through a non-zero localised \(\mathbf Q\)-algebra; it does not identify a \(p\)-adic point with a complex point.
5. The endpoint is disclosed as a release boundary, and the exploratory \(101:120\) scan is not promoted into the theorem corpus.

# References

Grochow, J. A. (2025). Multivariate Hensel lifting without assuming as many variables as equations. *The American Mathematical Monthly, 132*(4), 350-355. https://doi.org/10.1080/00029890.2024.2440297

Lewis, D., Perry, K., & Straub, A. (2019). An algorithmic approach to the Polydegree Conjecture for plane polynomial automorphisms. *Journal of Pure and Applied Algebra, 223*(12), 5346-5359. https://doi.org/10.1016/j.jpaa.2019.04.002

The Stacks Project Authors. (2026). *Flat modules and flat ring maps*, Lemma 10.39.15 (Tag 00HP). https://stacks.math.columbia.edu/tag/00HP
