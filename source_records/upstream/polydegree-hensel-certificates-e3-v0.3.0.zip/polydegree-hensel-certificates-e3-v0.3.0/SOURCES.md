# Load-bearing sources

| Source | Exact use | Pinning |
|---|---|---|
| Lewis, Perry & Straub, arXiv:1809.09681v1 | Definitions on preprint pages 2-3 and Theorem 4 | arXiv version, 13-page length, DOI, page range and authoritative URL pinned. A short local transcription is stored at `sources/LPS_SOURCE_EXTRACT.md`, SHA-256 `99df7fe81d1ea0c7cd0fa39f16df3f715b9474e0e38bcff2d83bb446bcb80917`. |
| Grochow (2025) | Modern multivariate Hensel reference | DOI 10.1080/00029890.2024.2440297 pinned. |
| Stacks Project Tag 00HP | Faithfully flat base change preserves non-zero modules | Stable tag pinned. |
| Weak Nullstellensatz | Complex point from non-zero finite-type \(\mathbf C\)-algebra | Standard theorem; the manuscript states the exact use. |

## Source-byte boundary

The arXiv PDF was parsed and visually inspected as version `1809.09681v1`, but its remote bytes could not be materialised inside this local build. The SHA-256 above therefore authenticates the package's load-bearing transcription, **not the source PDF**. A public archival build should copy the authoritative PDF where licensing and repository policy permit, record its own SHA-256, and bind that hash into the final manifest.
