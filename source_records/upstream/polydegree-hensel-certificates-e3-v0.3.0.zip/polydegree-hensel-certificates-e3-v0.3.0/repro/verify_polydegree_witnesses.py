#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, math, sys, time
from functools import lru_cache
from pathlib import Path
from typing import Any


def is_prime(n:int)->bool:
    if n<2:return False
    if n%2==0:return n==2
    r=int(math.isqrt(n))
    for q in range(3,r+1,2):
        if n%q==0:return False
    return True

@lru_cache(None)
def weighted_compositions(total:int)->tuple[tuple[int,int,int],...]:
    out=[]
    for a3 in range(total//3+1):
        for a2 in range((total-3*a3)//2+1):
            a1=total-2*a2-3*a3
            out.append((a1,a2,a3))
    return tuple(out)

def multinomial_tail(a:tuple[int,int,int], tail:int)->int:
    s=sum(a)
    ans=math.comb(tail+s, tail)
    rem=s
    for ai in a:
        ans*=math.comb(rem,ai)
        rem-=ai
    return ans

@lru_cache(None)
def g_terms(d:int)->tuple[tuple[int,int,int,int],...]:
    out=[]
    for a in weighted_compositions(d):
        c=(-1)**sum(a)*multinomial_tail(a,d)
        out.append((*a,c))
    return tuple(out)

@lru_cache(None)
def alpha_terms(i:int,j:int)->tuple[tuple[int,int,int,int],...]:
    target=j-i
    if target<0:return tuple()
    out=[]
    for a in weighted_compositions(target):
        c=(-1)**sum(a)*multinomial_tail(a,j+2)
        out.append((*a,c))
    return tuple(out)

def eval_g_and_derivatives(d:int,u:int,v:int,p:int)->tuple[int,int,int]:
    val=du=dv=0
    for a1,a2,a3,c in g_terms(d):
        # x1=1
        uv=(u**a2)*(v**a3)
        val += c*uv
        if a2:
            du += c*a2*(u**(a2-1))*(v**a3)
        if a3:
            dv += c*a3*(u**a2)*(v**(a3-1))
    q=d+1
    assert val%q==0 and du%q==0 and dv%q==0
    return (val//q)%p,(du//q)%p,(dv//q)%p

def eval_alpha(i:int,j:int,u:int,v:int,p:int)->int:
    total=0
    for a1,a2,a3,c in alpha_terms(i,j):
        total += c*(u**a2)*(v**a3)
    return total%p

def det3(M:list[list[int]],p:int)->int:
    return (M[0][0]*(M[1][1]*M[2][2]-M[1][2]*M[2][1])
            -M[0][1]*(M[1][0]*M[2][2]-M[1][2]*M[2][0])
            +M[0][2]*(M[1][0]*M[2][1]-M[1][1]*M[2][0]))%p

def direct_certificate(d:int,u:int,v:int,p:int)->dict[str,Any]:
    gd,gdu,gdv=eval_g_and_derivatives(d,u,v,p)
    gd1,g1du,g1dv=eval_g_and_derivatives(d+1,u,v,p)
    gd2,_,_=eval_g_and_derivatives(d+2,u,v,p)
    M=[[eval_alpha(i,j,u,v,p) for j in range(d-1,d+2)] for i in range(3)]
    return {'g_d':gd,'g_d1':gd1,'g_d2':gd2,'a':det3(M,p),
            'jac23':(gdu*g1dv-gdv*g1du)%p,'alpha_matrix':M,
            'jacobian_rows_x2_x3':[[gdu,gdv],[g1du,g1dv]]}

# Algebraically distinct internal formal-series implementation.
def conv(A:list[int],B:list[int],N:int,p:int)->list[int]:
    C=[0]*(N+1)
    for i,a in enumerate(A):
        if not a:continue
        upper=min(len(B)-1,N-i)
        for j in range(upper+1):
            b=B[j]
            if b:C[i+j]=(C[i+j]+a*b)%p
    return C

def inv_composition_coeffs(u:int,v:int,N:int,p:int)->list[int]:
    I=[0]*(N+1);I[1]=1
    for n in range(2,N+1):
        A=I[:n+1]
        I2=conv(A,A,n,p); I3=conv(I2,A,n,p); I4=conv(I3,A,n,p)
        I[n]=(-I2[n]-u*I3[n]-v*I4[n])%p
    return I

def inv_composition_dual(u:int,v:int,N:int,p:int,which:str)->list[tuple[int,int]]:
    I=[(0,0)]*(N+1);I[1]=(1,0)
    def cv(A:list[tuple[int,int]],B:list[tuple[int,int]],n:int)->list[tuple[int,int]]:
        C=[(0,0)]*(n+1)
        for i,(a,da) in enumerate(A):
            if i>n:break
            for j,(b,db) in enumerate(B):
                if i+j>n:break
                c,dc=C[i+j]
                C[i+j]=((c+a*b)%p,(dc+da*b+a*db)%p)
        return C
    for n in range(2,N+1):
        A=I[:n+1]
        I2=cv(A,A,n);I3=cv(I2,A,n);I4=cv(I3,A,n)
        val=(-I2[n][0]-u*I3[n][0]-v*I4[n][0])%p
        der=(-I2[n][1]-u*I3[n][1]-v*I4[n][1])%p
        if which=='u':der=(der-I3[n][0])%p
        elif which=='v':der=(der-I4[n][0])%p
        I[n]=(val,der)
    return I

def phi_inverse(u:int,v:int,N:int,p:int)->list[int]:
    a=[0]*(N+1);a[0]=1
    for n in range(1,N+1):
        a[n]=-(a[n-1]+(u*a[n-2] if n>=2 else 0)+(v*a[n-3] if n>=3 else 0))%p
    return a

def pow_series(base:list[int],e:int,N:int,p:int)->list[int]:
    out=[0]*(N+1);out[0]=1
    cur=base[:]
    while e:
        if e&1:out=conv(out,cur,N,p)
        e//=2
        if e:cur=conv(cur,cur,N,p)
    return out

def alpha_series(i:int,j:int,u:int,v:int,p:int)->int:
    target=j-i
    psi=phi_inverse(u,v,target,p)
    return pow_series(psi,j+3,target,p)[target]

def series_certificate(d:int,u:int,v:int,p:int)->dict[str,Any]:
    I=inv_composition_coeffs(u,v,d+3,p)
    Du=inv_composition_dual(u,v,d+2,p,'u')
    Dv=inv_composition_dual(u,v,d+2,p,'v')
    M=[[alpha_series(i,j,u,v,p) for j in range(d-1,d+2)] for i in range(3)]
    J=(Du[d+1][1]*Dv[d+2][1]-Dv[d+1][1]*Du[d+2][1])%p
    return {'g_d':I[d+1],'g_d1':I[d+2],'g_d2':I[d+3],
            'a':det3(M,p),'jac23':J,'alpha_matrix':M,
            'jacobian_rows_x2_x3':[[Du[d+1][1],Dv[d+1][1]],[Du[d+2][1],Dv[d+2][1]]]}

def main()->int:
    parser=argparse.ArgumentParser()
    parser.add_argument('--data',type=Path,required=True)
    parser.add_argument('--json',type=Path)
    args=parser.parse_args()
    raw=json.loads(args.data.read_text())
    rows=raw['witnesses'] if isinstance(raw,dict) and 'witnesses' in raw else [dict({'d':int(k)},**v) for k,v in raw.items()]
    rows=sorted(rows,key=lambda r:int(r['d']))
    failures=[]; results=[]
    t0=time.perf_counter()
    if [int(r['d']) for r in rows] != list(range(50,101)):
        failures.append('witness d-values are not exactly 50..100')
    for r in rows:
        d=int(r['d']);p=int(r['p']);point=r['point'];
        if len(point)!=3 or int(point[0])!=1:failures.append(f'd={d}: point must be [1,u,v]')
        _,u,v=map(int,point)
        if not is_prime(p):failures.append(f'd={d}: p={p} is not prime')
        A=direct_certificate(d,u,v,p)
        B=series_certificate(d,u,v,p)
        exp={'g_d':0,'g_d1':0,'g_d2':int(r['g_next']),'a':int(r['a']),'jac23':int(r['jac23'])}
        for key,val in exp.items():
            if A[key]!=val:failures.append(f'd={d}: direct {key}={A[key]} expected {val}')
            if B[key]!=val:failures.append(f'd={d}: series {key}={B[key]} expected {val}')
        if A!=B:failures.append(f'd={d}: implementations disagree')
        if A['g_d2']==0 or A['a']==0 or A['jac23']==0:failures.append(f'd={d}: Hensel unit condition fails')
        results.append({'d':d,'p':p,'point':[1,u,v],'certificate':A,'status':'PASS' if not any(s.startswith(f'd={d}:') for s in failures) else 'FAIL'})
    elapsed=time.perf_counter()-t0
    overall='PASS' if not failures else 'FAIL'
    report={'project':'Polydegree e=3 Hensel witness extension','version':'0.2.0','date':'2026-08-07',
            'arithmetic':'exact integer and finite-field arithmetic','internal_implementations':['direct multinomial evaluation','formal power-series inversion with dual derivatives'],
            'range':[50,100],'witnesses_passed':sum(r['status']=='PASS' for r in results),
            'witnesses_total':len(results),'overall_status':overall,'elapsed_seconds':elapsed,
            'failures':failures,'results':results}
    print('Polydegree e=3 Hensel witness verification')
    print('Internal algebraically distinct Python implementations: 2')
    print(f"Witnesses passed: {report['witnesses_passed']}/{len(results)}")
    print(f'Overall status: {overall}')
    if args.json:
        args.json.parent.mkdir(parents=True,exist_ok=True)
        args.json.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n')
    if failures:
        for f in failures:print('FAIL:',f,file=sys.stderr)
        return 1
    return 0
if __name__=='__main__':raise SystemExit(main())
