#!/usr/bin/env python3
"""Deterministic bounded search for smooth e=3 Polydegree witnesses.

The script scans primes and affine points in ascending order and returns the
first certificate satisfying the Hensel-specialization conditions for each d.
It is a discovery replay, not part of the proof: the compact witness verifier
independently checks the frozen certificate table by two implementations.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import time
from functools import lru_cache
from pathlib import Path


PRIMES = (5, 7, 11, 13, 17, 19, 23, 29, 31, 37)


@lru_cache(None)
def compositions(total: int) -> tuple[tuple[int, int, int], ...]:
    out: list[tuple[int, int, int]] = []
    for a3 in range(total // 3 + 1):
        for a2 in range((total - 3 * a3) // 2 + 1):
            a1 = total - 2 * a2 - 3 * a3
            out.append((a1, a2, a3))
    return tuple(out)


def multinomial_tail(a: tuple[int, int, int], tail: int) -> int:
    remaining = sum(a)
    value = math.comb(tail + remaining, tail)
    for entry in a:
        value *= math.comb(remaining, entry)
        remaining -= entry
    return value


@lru_cache(None)
def g_terms(d: int) -> tuple[tuple[tuple[int, int, int], int], ...]:
    terms = []
    for a in compositions(d):
        numerator = (-1) ** sum(a) * multinomial_tail(a, d)
        quotient, remainder = divmod(numerator, d + 1)
        if remainder:
            raise ArithmeticError(f"non-integral g coefficient at d={d}, a={a}")
        terms.append((a, quotient))
    return tuple(terms)


@lru_cache(None)
def alpha_terms(i: int, j: int) -> tuple[tuple[tuple[int, int, int], int], ...]:
    return tuple(
        (a, (-1) ** sum(a) * multinomial_tail(a, j + 2))
        for a in compositions(j - i)
    )


def evaluate(
    terms: tuple[tuple[tuple[int, int, int], int], ...],
    point: tuple[int, int, int],
    p: int,
) -> int:
    value = 0
    for a, coefficient in terms:
        term = coefficient % p
        for coordinate, exponent in zip(point, a):
            term = term * pow(coordinate, exponent, p) % p
        value = (value + term) % p
    return value


def derivative(
    terms: tuple[tuple[tuple[int, int, int], int], ...],
    point: tuple[int, int, int],
    p: int,
    variable: int,
) -> int:
    value = 0
    for a, coefficient in terms:
        if a[variable] == 0:
            continue
        term = coefficient * a[variable]
        for index, (coordinate, exponent) in enumerate(zip(point, a)):
            term *= pow(coordinate, exponent - (index == variable), p)
        value = (value + term) % p
    return value


def det3(matrix: list[list[int]], p: int) -> int:
    return (
        matrix[0][0] * (matrix[1][1] * matrix[2][2] - matrix[1][2] * matrix[2][1])
        - matrix[0][1] * (matrix[1][0] * matrix[2][2] - matrix[1][2] * matrix[2][0])
        + matrix[0][2] * (matrix[1][0] * matrix[2][1] - matrix[1][1] * matrix[2][0])
    ) % p


def find_witness(d: int) -> dict[str, object] | None:
    g = {n: g_terms(n) for n in (d, d + 1, d + 2)}
    alpha = [
        [alpha_terms(i, j) for j in range(d - 1, d + 2)]
        for i in range(3)
    ]
    for p in PRIMES:
        for u in range(p):
            for v in range(p):
                point = (1, u, v)
                if evaluate(g[d], point, p) or evaluate(g[d + 1], point, p):
                    continue
                g_next = evaluate(g[d + 2], point, p)
                if not g_next:
                    continue
                matrix = [
                    [evaluate(alpha[i][column], point, p) for column in range(3)]
                    for i in range(3)
                ]
                determinant = det3(matrix, p)
                if not determinant:
                    continue
                jacobian = (
                    derivative(g[d], point, p, 1) * derivative(g[d + 1], point, p, 2)
                    - derivative(g[d], point, p, 2) * derivative(g[d + 1], point, p, 1)
                ) % p
                if not jacobian:
                    continue
                return {
                    "d": d,
                    "p": p,
                    "point": list(point),
                    "g_next": g_next,
                    "a": determinant,
                    "jac23": jacobian,
                }
    return None


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--d-min", type=int, default=50)
    parser.add_argument("--d-max", type=int, default=100)
    parser.add_argument("--json", type=Path)
    parser.add_argument("--csv", type=Path)
    parser.add_argument(
        "--compare",
        type=Path,
        default=None,
        help="Optional frozen witness JSON to compare with the deterministic search output.",
    )
    args = parser.parse_args()
    if args.d_min < 2 or args.d_max < args.d_min:
        parser.error("require 2 <= d-min <= d-max")

    started = time.perf_counter()
    witnesses = []
    missing = []
    for d in range(args.d_min, args.d_max + 1):
        witness = find_witness(d)
        if witness is None:
            missing.append(d)
            print(f"d={d}: no witness within frozen search boundary", flush=True)
        else:
            witnesses.append(witness)
            print(
                f"d={d}: p={witness['p']}, point={witness['point']}, "
                f"units=({witness['g_next']},{witness['a']},{witness['jac23']})",
                flush=True,
            )

    result = {
        "schema": "evidence-press.polydegree-hensel-search.v1",
        "date": "2026-08-07",
        "search_order": {"primes": list(PRIMES), "points": "lexicographic (x2,x3), x1=1"},
        "range": {"d_min": args.d_min, "d_max": args.d_max},
        "witnesses": witnesses,
        "missing": missing,
        "elapsed_seconds": time.perf_counter() - started,
    }

    exact_match = None
    if args.compare is not None:
        frozen_bytes = args.compare.read_bytes()
        frozen_raw = json.loads(frozen_bytes)
        frozen = frozen_raw.get("witnesses", frozen_raw)
        exact_match = witnesses == frozen
        result["exact_match_to_frozen_witnesses"] = exact_match
        result["frozen_witness_data_sha256"] = hashlib.sha256(frozen_bytes).hexdigest()
        print(f"Exact match to frozen witnesses: {exact_match}")
    if args.json:
        args.json.parent.mkdir(parents=True, exist_ok=True)
        args.json.write_text(json.dumps(result, indent=2) + "\n")
    if args.csv:
        args.csv.parent.mkdir(parents=True, exist_ok=True)
        with args.csv.open("w", newline="") as handle:
            writer = csv.writer(handle)
            writer.writerow(["d", "p", "x1", "x2", "x3", "g_d_plus_2", "a_d_3", "jacobian_x2_x3"])
            for row in witnesses:
                writer.writerow([row["d"], row["p"], *row["point"], row["g_next"], row["a"], row["jac23"]])
    print(f"Covered: {len(witnesses)}/{args.d_max - args.d_min + 1}")
    print(f"Missing: {missing}")
    return 0 if not missing and exact_match is not False else 1


if __name__ == "__main__":
    raise SystemExit(main())
