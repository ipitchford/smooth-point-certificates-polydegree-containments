#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python repro/verify_polydegree_witnesses.py \
  --data data/polydegree_e3_witnesses_50_100.json \
  --json repro/polydegree_witness_report.json
python repro/test_mutations.py | tee repro/polydegree_mutation_report.txt
python repro/search_polydegree_witnesses.py \
  --d-min 50 --d-max 100 \
  --compare data/polydegree_e3_witnesses_50_100.json \
  --json repro/search_report.json \
  --csv repro/search_report.csv
