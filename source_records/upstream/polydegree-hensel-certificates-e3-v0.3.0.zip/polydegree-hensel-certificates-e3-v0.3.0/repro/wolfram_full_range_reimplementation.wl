(*
Full-range Wolfram Language reimplementation from the definitions in
Lewis-Perry-Straub, arXiv:1809.09681v1, pages 2-3.
No Python code or generated coefficient tables are imported.
*)
ClearAll[weightedTriples, ppow, gExact, alphaExact, gDerivExact, cert];
ppow[x_Integer, n_Integer?NonNegative] := If[n == 0, 1, x^n];
weightedTriples[n_Integer?NonNegative] := Flatten[
  Table[{n - 2 a2 - 3 a3, a2, a3}, {a3, 0, Floor[n/3]},
        {a2, 0, Floor[(n - 3 a3)/2]}], 1];

gExact[d_Integer?Positive, u_Integer, v_Integer] := Quotient[
  Total[Map[Function[a,
    (-1)^Total[a] Multinomial[a[[1]], a[[2]], a[[3]], d]
      ppow[u, a[[2]]] ppow[v, a[[3]]]], weightedTriples[d]]], d + 1];

alphaExact[i_Integer, j_Integer, u_Integer, v_Integer] :=
  If[j - i < 0, 0,
    Total[Map[Function[a,
      (-1)^Total[a] Multinomial[a[[1]], a[[2]], a[[3]], j + 2]
        ppow[u, a[[2]]] ppow[v, a[[3]]]], weightedTriples[j - i]]]];

gDerivExact[d_Integer?Positive, u_Integer, v_Integer, var_Integer] := Quotient[
  Total[Map[Function[a, Module[{e = a[[var]], eu, ev},
    If[e == 0, 0,
      eu = a[[2]] - Boole[var == 2];
      ev = a[[3]] - Boole[var == 3];
      (-1)^Total[a] Multinomial[a[[1]], a[[2]], a[[3]], d] e
        ppow[u, eu] ppow[v, ev]]]], weightedTriples[d]]], d + 1];

cert[{d_, p_, u_, v_, expectedNext_, expectedA_, expectedJ_}] := Module[
  {gd, gd1, gd2, mat, adet, ju, jv, j1u, j1v, jac, got, expected},
  gd = Mod[gExact[d, u, v], p];
  gd1 = Mod[gExact[d + 1, u, v], p];
  gd2 = Mod[gExact[d + 2, u, v], p];
  mat = Table[Mod[alphaExact[i, j, u, v], p], {i, 0, 2}, {j, d - 1, d + 1}];
  adet = Mod[Det[mat], p];
  ju = Mod[gDerivExact[d, u, v, 2], p];
  jv = Mod[gDerivExact[d, u, v, 3], p];
  j1u = Mod[gDerivExact[d + 1, u, v, 2], p];
  j1v = Mod[gDerivExact[d + 1, u, v, 3], p];
  jac = Mod[ju j1v - jv j1u, p];
  got = {gd, gd1, gd2, adet, jac};
  expected = {0, 0, expectedNext, expectedA, expectedJ};
  <|"d" -> d, "p" -> p, "point" -> {1, u, v}, "got" -> got,
    "expected" -> expected,
    "pass" -> (got === expected && And @@ Thread[{gd2, adet, jac} != 0])|>
];

witnesses = {{50,5,3,1,4,2,1},{51,37,3,24,14,17,10},{52,13,8,4,1,3,5},{53,23,6,3,18,18,5},{54,11,1,8,10,2,2},{55,5,4,3,4,3,4},{56,5,2,1,4,3,1},{57,7,0,1,6,3,1},{58,11,2,4,2,6,6},{59,5,2,4,4,3,3},{60,19,3,10,2,15,8},{61,17,6,5,12,8,16},{62,7,6,6,5,5,6},{63,19,16,11,2,6,2},{64,5,0,4,1,1,4},{65,11,3,2,4,10,3},{66,11,7,4,4,5,9},{67,11,4,6,7,9,9},{68,11,0,4,6,7,2},{69,7,1,5,6,1,1},{70,7,2,1,3,4,4},{71,7,2,3,3,6,4},{72,13,8,6,5,10,7},{73,17,0,12,5,16,1},{74,23,17,9,8,12,8},{75,17,6,6,5,10,13},{76,5,2,1,2,1,4},{77,7,5,5,4,3,4},{78,13,0,10,7,8,5},{79,5,0,2,1,4,1},{80,37,35,1,30,19,1},{81,13,9,11,3,8,9},{82,13,5,7,2,9,9},{83,7,1,2,6,1,1},{84,19,5,3,7,12,2},{85,13,8,6,9,11,5},{86,17,4,16,8,2,7},{87,11,10,3,3,7,5},{88,11,2,2,4,7,6},{89,5,0,4,4,4,4},{90,13,1,7,2,5,4},{91,5,2,4,1,3,4},{92,23,2,15,13,22,8},{93,23,3,18,21,15,14},{94,13,9,6,3,8,9},{95,13,10,0,3,10,11},{96,19,3,14,13,5,14},{97,7,2,1,2,1,3},{98,7,2,2,2,6,2},{99,19,6,5,17,9,15},{100,19,0,6,14,5,11}};
results = cert /@ witnesses;
<|"wolfram_version" -> $Version, "system_id" -> $SystemID,
  "cases" -> Length[results],
  "passed" -> Count[Lookup[results, "pass"], True],
  "failed_d" -> Cases[results, a_ /; ! TrueQ[a["pass"]] :> a["d"]],
  "all_pass" -> And @@ Lookup[results, "pass"],
  "first" -> First[results],
  "interior" -> SelectFirst[results, #d == 75 &],
  "last" -> Last[results]|>
