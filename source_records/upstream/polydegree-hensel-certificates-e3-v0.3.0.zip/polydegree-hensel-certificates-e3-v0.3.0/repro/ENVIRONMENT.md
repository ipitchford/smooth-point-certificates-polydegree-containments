# Execution environments

## Python replay
- Python: 3.13.5
- Third-party dependencies: none
- OS used for frozen replay: Linux-6.18.35-x86_64-with-glibc2.41

## Separate CAS replay
- Wolfram Language: 15.0.1 for Linux x86 (64-bit), 2 July 2026
- System ID: Linux-x86-64
- Full-range execution date: 7 August 2026
