#!/usr/bin/env python3
from __future__ import annotations
import copy, importlib.util, json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
DATA = ROOT / "data/polydegree_e3_witnesses_50_100.json"

spec = importlib.util.spec_from_file_location("verifier", HERE / "verify_polydegree_witnesses.py")
assert spec and spec.loader
verifier = importlib.util.module_from_spec(spec)
spec.loader.exec_module(verifier)


def row_accepts(row: dict) -> bool:
    d = int(row["d"]); p = int(row["p"]); _, u, v = map(int, row["point"])
    A = verifier.direct_certificate(d, u, v, p)
    B = verifier.series_certificate(d, u, v, p)
    expected = {"g_d": 0, "g_d1": 0, "g_d2": int(row["g_next"]),
                "a": int(row["a"]), "jac23": int(row["jac23"])}
    return (A == B and all(A[k] == val for k, val in expected.items())
            and A["g_d2"] != 0 and A["a"] != 0 and A["jac23"] != 0)


def complete(rows: list[dict]) -> bool:
    return sorted(int(r["d"]) for r in rows) == list(range(50, 101))


def main() -> int:
    base = json.loads(DATA.read_text(encoding="utf-8"))
    rows = base["witnesses"]
    if not complete(rows) or not row_accepts(rows[0]):
        print("Baseline control failed")
        return 1

    controls: list[tuple[str, bool]] = []

    a = copy.deepcopy(rows[0])
    a["g_next"] = (a["g_next"] + 1) % a["p"]
    controls.append(("corrupted G_next", not row_accepts(a)))

    b = copy.deepcopy(rows[0])
    b["point"][1] = (b["point"][1] + 1) % b["p"]
    controls.append(("corrupted point", not row_accepts(b)))

    controls.append(("missing d=100", not complete(rows[:-1])))

    shifted = copy.deepcopy(rows)
    shifted[0]["d"] = 51
    controls.append(("one-step index shift", not complete(shifted)))

    passed = sum(ok for _, ok in controls)
    print(f"Polydegree mutation controls rejected: {passed}/{len(controls)}")
    for name, ok in controls:
        print(("PASS" if ok else "FAIL") + ": " + name)
    return 0 if passed == len(controls) else 1

if __name__ == "__main__":
    raise SystemExit(main())
