# Assurance statement

## Completed

- Numbered derivation from the Lewis-Perry-Straub definitions to every encoded object and index.
- Written Hensel/localisation/faithful-base-change proof.
- 51/51 exact Python replay under two internal algebraically distinct methods.
- 51/51 separate Wolfram Language replay from the published weighted sums.
- Hand traces at the first, middle and last frozen cases.
- Four shipped mutation/negative controls.
- Deterministic discovery replay and exact table comparison.
- Machine-readable claims, provenance, source ledger, privacy and publication-integrity reports, environment pinning, RO-Crate and manifest.

## Important distinction

`Separate Wolfram Language implementation` means a different computer-algebra language and independently written formulas. It does not mean reproduction by an unaffiliated person or research group.

## Remaining risk

The principal residual risk is a shared mathematical misunderstanding of Lewis-Perry-Straub Theorem 4 or its intended conventions. The manuscript now makes the source bridge hand-auditable, but specialist review remains valuable.

## Frozen boundary

The interval \(50\le d\le100\) is a versioned snapshot. The same discovery code found witnesses for \(101\le d\le120\) during review; those exploratory rows are excluded rather than used to create another arbitrary-bound claim.
