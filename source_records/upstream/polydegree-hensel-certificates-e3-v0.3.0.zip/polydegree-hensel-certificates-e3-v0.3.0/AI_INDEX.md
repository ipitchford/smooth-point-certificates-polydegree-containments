# Agent index

## Start here

1. `MANUSCRIPT.md` - proof, encoding lemmas and bounded result.
2. `ENCODING_AUDIT.md` - source-to-code map.
3. `ASSURANCE.md` and `CLAIM_STATUS.json` - evidence status.
4. `data/polydegree_e3_witnesses_50_100.json` - frozen certificates.

## Replay

```bash
python repro/verify_polydegree_witnesses.py --data data/polydegree_e3_witnesses_50_100.json --json /tmp/report.json
python repro/test_mutations.py
python repro/search_polydegree_witnesses.py --d-min 50 --d-max 100 --compare data/polydegree_e3_witnesses_50_100.json
```

Expected: Python 51/51, mutations 4/4 rejected, exact discovery-table match. The Wolfram frozen report records 51/51.
